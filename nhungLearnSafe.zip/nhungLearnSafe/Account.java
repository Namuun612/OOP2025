/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nhungLearnSafe;

/**
 *
 * @author surface pro 6
 */
public class Account {
    private String username, password;
    private String[] quiz;

    public Account(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Account() {
    }
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String[] getQuiz() {
        return quiz;
    }

    public void setQuiz(String[] quiz) {
        this.quiz = quiz;
    }
    
    public String showInfo(){
        return "Username: "+ username+"\n"+
                "Password: "+ password;
    }

    
}
