/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package plansafe;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class EmerContact implements Contact{
    private String contactName, phone, relationship;

    public EmerContact(String contactName, String phone, String relationship) {
        this.contactName = contactName;
        this.phone = phone;
        this.relationship = relationship;
    }

    public EmerContact() {
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }
    
    @Override
    public void saveContact() {
        try(FileWriter fw = new FileWriter(("contact.txt"), true)) {
            fw.write("Name: "+contactName + "\n");  
            fw.write("Phone: " + phone + "\n");  
            fw.write("Relationship: " + relationship + "\n");  
            fw.write("\n");  
            JOptionPane.showMessageDialog(null, "Contact saved to contact file.");
        }catch(IOException e) {
            JOptionPane.showMessageDialog(null,"Error saving contact to file: "+e);
        }
    }

    @Override
    public String accessContact() {
        StringBuilder sb = new StringBuilder();
        
        try(BufferedReader br = new BufferedReader(new FileReader("contact.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n"); 
            }
        }catch(IOException e) {
                JOptionPane.showMessageDialog(null, "Error reading contact: "+e);
            }

        return sb.toString();
    }
    
    public String printDetails() {
        return "\nName: " + contactName +"\nPhone: " + phone +"\nRelationship: " + relationship;
    }
    
    public void seeInstructionInput(){
        JOptionPane.showMessageDialog(null, """
                                            CONTACT NAME:
                                            - Enter the name of the person the user would like to contact during emergency
                                            
                                            PHONE NUMBER:
                                            - Provide a phone number of the person
                                            
                                            RELATIONSHIP:
                                            - Enter a relatioship that the user have with the contact person.
                                              (Example: sister, friend, neighbour, uncle, etc)
                                            
                                            """);
    }
    
    public void seeInstructionButton(){
        JOptionPane.showMessageDialog(null, """
                                            ADD: (using array and file)
                                            - Add the values given by the user to the array and the file.
                                            
                                            DISPLAY: (using file)
                                            - Display the values in the file.
                                            
                                            SEARCH: (using array)
                                            - Search the values in the array based on the contact name.
                                            - It will not search from file.
                                            
                                            DELETE: (using array and updating file)
                                            - Delete the value from the array based on the contact name.
                                            - Values in the file will be updated with the values in array.
                                            
                                            All functionality will show error message in case of irregular activity.
                                                                                        
                                            """);
    }
}
