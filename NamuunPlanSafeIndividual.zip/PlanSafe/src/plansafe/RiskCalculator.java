/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package plansafe;

/**
 *
 * @author Dell
 */
public interface RiskCalculator {
    double calculateRisk(double hazard, double exposure, double vulnerability);
}
