/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nhungLearnSafe;

import javax.swing.JOptionPane;

/**
 *
 * @author surface pro 6
 */
public class FloodQuiz extends Quiz{
    private String[] questions;
    private String[][] answers;

    public FloodQuiz(String[] questions, String[][] answers, String title, String topic, String length) {
        super(title, topic, length);
        this.questions = questions;
        this.answers = answers;
    }

    public FloodQuiz() {
    }

    public String[] getQuestions() {
        return questions;
    }

    public void setQuestions(String[] questions) {
        this.questions = questions;
    }

    public String[][] getAnswers() {
        return answers;
    }

    public void setAnswers(String[][] answers) {
        this.answers = answers;
    }
    
    @Override
    public void showLesson(){
        JOptionPane.showMessageDialog(null, """
                                            As part of planning and preparedness for a potential flooding event, you should
                                            
                                            1. Identify and stay informed via resources that provide regular updates and information on the weather and flooding risk
                                            2. Create a flood kit that can be easily found if needed
                                            3. Develop and maintain a plan for evacuation of your home or business, if required during a flooding event. The plan should also include a list of essential items you would need to take with you e.g. essentials for children (such as sterilised bottles, nappies, milk, baby food), medication.
                                            4. Write a list of your most valuable possessions and where they are stored
                                            5. Consider how to communicate with loved ones or staff in your business in the event of a flood
                                            """);
        JOptionPane.showMessageDialog(null, """
                                            Extra preparation for flooding is important if you are an elderly person, particularly if you are living alone.
                                            
                                            1. Plan an evacuation route and destination.
                                            2. Keep an up to date list of important and useful contact numbers e.g. family, neighbours, local health services, and emergency services.
                                            """);
    }
}
