/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package namuunPlanSafe;

import javax.swing.JOptionPane;

/**
 *
 * @author namuun-nergui
 */
public class Checklist extends PlanSafe implements ProgressTracker{
    private double completed, list;
    private double progress;
    
    public Checklist() {
        
    }   

    public Checklist(double completed, String disasterType) {
        super(disasterType);
        this.completed = completed;
        list = 5;
    }


    public double getCompleted() {
        return completed;
    }

    public void setCompleted(double completed) {
        this.completed = completed;
    }
    
    @Override
    public String progressTrack(double list, double completed) {
        progress = completed / list * 100;
        return String.format("%f", progress);
    }
    
    @Override
    public String printDetails() {
        return "Number of completed checklist: " + completed+"\nChecklist Progress: " + progress + "%";
    }
    
    public void seeInstruction(){
        JOptionPane.showMessageDialog(null, """
                                            - The checklist panel will appear based on the activity selected on the main page.
                                            - If user chose a disaster type on the main page, the checklist for that specific disaster will be displayed.
                                            - The user can still switch and view the checklists of other disaster types.
                                            - User can also add your own custom checklist items (up to 5 items allowed) by choosing 'Create Your Own List'.
                                            - User can track their progress based on how many checklist items you have completed by pressing 'Check' button.
                                            """);
    }
}
