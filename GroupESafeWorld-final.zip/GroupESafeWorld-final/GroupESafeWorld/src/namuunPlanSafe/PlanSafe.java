/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package namuunPlanSafe;

import javax.swing.JOptionPane;

/**
 *
 * @author namuun-nergui
 */
public class PlanSafe {
    protected String disasterType;
    
    public PlanSafe(){
        
    }

    public PlanSafe(String disasterType) {
        this.disasterType = disasterType;
    }

    public String getDisasterType() {
        return disasterType;
    }

    public void setDisasterType(String disasterType) {
        this.disasterType = disasterType;
    }
    
    public String printDetails(){
        return "Disaster: "+disasterType;
    }
    
    public void seeInstruc(){
        JOptionPane.showMessageDialog(null, """
                                            1. Location Risk Calculator
                                            - You must select a disaster type before using this section.
                                            
                                            2. Checklist
                                            - Selecting a disaster type is optional.
                                            - If you choose one, the checklist will match the chosen disaster.
                                            - If not, the section still works normally.
                                            
                                            3. Emergency Contact
                                            - No disaster type is required.
                                            - This section contains the contacts of the people the user would 
                                              like to contact in case of any emergency.
                                            """);
    }
}
